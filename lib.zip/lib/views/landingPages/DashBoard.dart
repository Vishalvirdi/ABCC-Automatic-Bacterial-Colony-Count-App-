import 'dart:io';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';

import 'package:star_menu/star_menu.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  final CollectionReference processedColoniesReference =
      FirebaseFirestore.instance.collection("ProcessedColonies");
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  File? _imageFile;
  String _apiUrl =
      'https://project-phase.vercel.app/'; // Replace with your actual Vercel API URL
  String _uploadMessage = '';
  dynamic responseData;

  Future<void> _selectImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
        source: selectedIndex == 1 ? ImageSource.camera : ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
        _uploadMessage = ''; // Clear previous message
      });
    }
  }

  int selectedIndex = 0;

  Future<void> _uploadImage() async {
    if (_imageFile == null) {
      setState(() {
        _uploadMessage = 'Please select an image first.';
      });
      return;
    }

    final request = http.MultipartRequest('POST', Uri.parse(_apiUrl));
    request.files
        .add(await http.MultipartFile.fromPath('image', _imageFile!.path));

    try {
      final response = await http.Response.fromStream(await request.send());
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          print(data);
          responseData = data;
          saveDataToFirebase();
          _uploadMessage = 'Image uploaded successfully!';
        });
      } else {
        setState(() {
          _uploadMessage =
              'Error uploading image. Status code: ${response.statusCode}';
        });
      }
    } on SocketException catch (e) {
      print('Error: Socket exception: $e');
      setState(() {
        _uploadMessage = 'Connection error: Failed to connect to API.';
      });
    } catch (e) {
      print('Error: $e');
      setState(() {
        _uploadMessage = 'An unexpected error occurred.';
      });
    }
  }

  final backgroundStarMenuController = StarMenuController();
  final centerStarMenuController = StarMenuController();
  final sliderValue = ValueNotifier<double>(0.5);
  final containerKey = GlobalKey();

  final otherEntries = <Widget>[
    Container(
      height: 60,
      width: 120,
    ),
    Chip(
      label: Container(
        width: 80,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Camera"),
            Icon(Icons.camera_alt),
          ],
        ),
      ),
    ),
    Chip(
      label: Container(
        width: 80,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Gallery"),
            Icon(Icons.image),
          ],
        ),
      ),
    ),
  ];

  Future<void> saveDataToFirebase() async {
    try {
      final response = await processedColoniesReference.add({
        "colonies": responseData["colony_count"],
        "processed_image": responseData["processed_image"]
      });
      print(response);
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          // Show dialog box when the user tries to exit the app
          bool exit = await showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Exit App'),
              content: Text('Are you sure you want to exit?'),
              actions: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  child: Text('No'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  child: Text('Yes'),
                ),
              ],
            ),
          );

          return exit ??
              false; // Return false to prevent exiting if exit is null
        },
        child: Scaffold(
          key: _key,
          backgroundColor: Colors.blue.withOpacity(.1),
          floatingActionButton: FloatingActionButton(
            onPressed: () {},
            child: Icon(Icons.file_upload_outlined),
          ).addStarMenu(
            items: otherEntries,
            onItemTapped: (index, c) {
              setState(() {
                selectedIndex = index;
              });
              if (index != 0) {
                _selectImage();
              }
              c.closeMenu!();
            },
            params: StarMenuParameters.dropdown(context).copyWith(
                useTouchAsCenter: true,
                linearShapeParams: LinearShapeParams(
                  space: 20,
                ),
                boundaryBackground:
                    BoundaryBackground(color: Colors.transparent)),
            controller: backgroundStarMenuController,
          ),
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: Text(
              "Count Colony",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: Colors.black),
            ),
            centerTitle: true,
          ),
          drawer: Drawer(
            child: Column(
              children: [
                Container(
                  height: 250,
                  width: MediaQuery.of(context).size.width,
                  color: Colors.blue.shade200,
                  child: Column(
                    children: [],
                  ),
                ),
                ListTile(
                  onTap: () {
                    _key.currentState!.closeDrawer();
                  },
                  leading: Icon(Icons.home_filled),
                  title: Text("Home"),
                ),
                ListTile(
                  onTap: () {},
                  leading: Icon(Icons.save_rounded),
                  title: Text("Processed Images"),
                ),
              ],
            ),
          ),
          body: SingleChildScrollView(
            child: Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: _selectImage,
                    child: Container(
                      height: 400,
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 5,
                            ),
                          ],
                          borderRadius: BorderRadius.circular(20)),
                      child: _imageFile == null
                          ? Center(
                              child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.cloud_upload_outlined,
                                  size: 30,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Select Image',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ))
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.file(_imageFile!)),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        elevation: 15,
                        backgroundColor: Colors.blue.shade200,
                        minimumSize:
                            Size(MediaQuery.of(context).size.width, 50),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5))),
                    onPressed: _uploadImage,
                    child: Text(
                      'Upload Image',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Text(
                      _uploadMessage,
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                          fontSize: 20),
                    ),
                  ),
                  responseData != null
                      ? Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                  blurRadius: 5,
                                )
                              ],
                              borderRadius: BorderRadius.circular(20)),
                          child: Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                responseData['processed_image'] != null
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(20),
                                        child: Image.memory(base64Decode(
                                            responseData['processed_image']!)))
                                    : Center(
                                        child: Text(
                                        'Processed Image',
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      )),
                                SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "Total colony counts: " +
                                          responseData['colony_count']
                                              .toString(),
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    IconButton(
                                        onPressed: () {
                                          // saveDecodedData();
                                        },
                                        icon: Icon(Icons.download))
                                  ],
                                )
                              ],
                            ),
                          ))
                      : Container(),
                  SizedBox(
                    height: 150,
                  )
                ],
              ),
            ),
          ),
        ));
  }
}

class IconMenu extends StatelessWidget {
  const IconMenu({
    required this.icon,
    required this.text,
    super.key,
  });

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 32),
        const SizedBox(height: 6),
        Text(text),
      ],
    );
  }
}
